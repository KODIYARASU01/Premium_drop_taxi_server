const MONGODB_URL =
  "mongodb+srv://kodiyarasu01:621714kodiC@cluster0.zgrb8vs.mongodb.net/?retryWrites=true&w=majority";
// const GOOGLE_MAP_API='AIzaSyBQAERPug2U72DLBeuSAG7PKqP-pEl9em8';

module.exports = MONGODB_URL;
// module.exports=GOOGLE_MAP_API;
